from flask import Flask
import alpaca_trade_api as tradeapi
import time

API_KEY = 'PKPCVTGLQ5EOFI53XXRL'
SECRET_KEY = 'WzCYQJVruR8j9dL28a6oz3YcmOSOIyhYItnqMbMT'
BASE_URL = 'https://api.alpaca.markets'

DIVIDEND_STOCKS = ['T', 'VZ', 'O', 'MAIN', 'PFE', 'KO']
TRADE_AMOUNT = 1.00

app = Flask(__name__)

@app.route('/run-bot', methods=['POST'])
def run_bot():
    try:
        api = tradeapi.REST(API_KEY, SECRET_KEY, BASE_URL, api_version='v2')
        account = api.get_account()
        cash = float(account.cash)

        for symbol in DIVIDEND_STOCKS:
            if cash < TRADE_AMOUNT:
                return "Insufficient funds", 200
            try:
                api.submit_order(
                    symbol=symbol,
                    notional=TRADE_AMOUNT,
                    side='buy',
                    type='market',
                    time_in_force='gtc'
                )
                time.sleep(1)
                cash -= TRADE_AMOUNT
            except Exception as e:
                print(f"Error buying {symbol}: {e}")
        return "Bot executed", 200
    except Exception as e:
        return str(e), 500

@app.route('/')
def home():
    return "Bot is online"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
